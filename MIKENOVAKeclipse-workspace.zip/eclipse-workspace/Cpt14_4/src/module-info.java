/**
 * 
 */
/**
 * @author Mike Novak
 *
 */
module Cpt14_4 {
	requires java.desktop;
}