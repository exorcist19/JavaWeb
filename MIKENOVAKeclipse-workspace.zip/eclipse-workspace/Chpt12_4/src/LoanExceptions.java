
public class LoanExceptions {

	public static void main(String[] args)
	{
	  
		try
		{
			new Loan(2, 60, 2000);
			Loan money = new Loan(5, -2, 3);
			new Loan(2, 60, 3000);
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("\nPROGRAM END");
			
	}

}
