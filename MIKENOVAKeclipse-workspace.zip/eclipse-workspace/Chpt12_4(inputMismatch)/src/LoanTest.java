
public class LoanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
			new Loan(2, 60, 2000);
			Loan money = new Loan(5, -2, 3);
			new Loan(2, 60, 2000);
			
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("\nPROGRAM END");
		
	}

}
