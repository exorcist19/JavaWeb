    private double annualInterestRate;
	private int numOfYears;
	private double loanAmount;
	
	public class Loan 
	{
	
		this(2, 5, 1000);
		
	}
	public Loan(double annualInterestRate, int numOfYears, double LoanAmount)
	{
			
	if (loanAmount <= 0)
		throw new IllegalArgumentException("Loan amount should be positive. ");
	
	if (numOfYears <= 0)
		
		throw new IllegalArgumentException("Annual interest rate should be positive. ");
	
	setLoanAmount(loanAmount);
	
	setAnnualInterestRate(annualInterestRate);
	
	setNumOfYears(numOfYears);
	
	}

	public double get AnnualInterestRate()
	{
		return annualInterestRate;
		
	}
	public void setAnnualInterestRate(double annualInterestRate)
	{
		if (annualInterestRate <= 0)
			throw new IllegalArgumentException("Annual interest rate should be positive. ");
		this.setAnnualInterestRate = annualInterestRate;
    }
	public int getNumOfYears;
	}
	{
		return NumOfYears;
	}
	public void setNumOfYears(int numOfYears)
	{
		if (numOfYears <= 0)
			throw new IllegalArgumentException("Number of years should be positive.");
		this.numOfYears = numOfYears;
	}
	public double getLoanAmount;
	{
		return loanAmount;
	}
	
	public void setLoanAmount(double loanAmount)
	{
		if (loanAmount <= 0)
			throw new IllegalArgumentException("Loan amount should be positive.");
		this.loanAmount = loanAmount;
	}
	public double monthlyPayment()
	{
		double monthlyInterestRate=annualInterestRate / 1200;
		return loanAmount * monthlyInterestRate / (1-(Math.pow(1/(1 + monthlyInterestRate),
				numOfYears * 12)));
	}
	public double totalPayment()
	{
		return monthlypayment() * numOfYears * 12;
	}
		
}
	
			
		}
	}

	