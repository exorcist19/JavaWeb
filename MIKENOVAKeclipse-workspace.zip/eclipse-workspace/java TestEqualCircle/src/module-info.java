/**
 * 
 */
/**
 * @author Mike Novak
 *
 */
module TestEqualCircle {
}