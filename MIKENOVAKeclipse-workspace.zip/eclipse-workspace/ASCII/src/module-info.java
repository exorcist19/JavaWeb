/**
 * 
 */
/**
 * @author Mike Novak
 *
 */
module ASCII {
}