import java.util.Scanner;

public class ASCII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Scanner scan = new Scanner(System.in);
			
			System.out.println("Enter an ASCII code:");
			int ascii = scan.nextInt();
			char c = (char)ascii;
			System.out.println("The character for ASCII code " + ascii + " is " + c);
	
	}

}
