import java.util.Scanner;
public class ProcessString {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String inputString = scanner.nextLine();
		//loop
		for(int i = 0)
		{
			if((i + 1)%2 == 1)
     	{
		printOddPositionChars=printOddPositionChars+
			inputString.charAt(i);			
		}
		}
		System.out.println("The characters at odd positions in the given string are: "+printOddPositionChars);
		
		
		
		
	}

}
