import java.util.Scanner;

public class Vowels {
   public static void main(String args[]) {
       
	   char letter;
	If(letter=='a' || letter=='A' || letter=='e' || letter=="E" 
			   || letter=='i' || letter=='I' 
			   || letter=='o' || letter=='O'
			   || letter=='u' || letter=="U" 
			   
	System.out.println(""+letter+" is a +"vowel");
	else
		System.out.printLn(""+letter+" is a"+"consonant");
	else
		System.out.print(""+letter+" is invalid"+input");	   
   }
}