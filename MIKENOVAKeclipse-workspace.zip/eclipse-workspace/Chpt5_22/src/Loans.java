import java.util.*;

public class Loans {

	public static void main(String[] args) 
	{
		int numOfYears;
		double annualInterest;
		double monthlyInterest;
        double loanAmount;
        double balance;
        double interest;
        double principal;
        double monthlyPayment;
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Loan Amount: ");
        loanAmount = input.nextDouble();
        System.out.print("Number of Years: ");
        numOfYears = input.nextInt();
        System.out.print("Annual Interest Rate: ");
        annualInterest = input.nextDouble();
        monthlyInterest = annualInterest/1200;
        
        //Calculate Loan
        
        monthlyPayment = loanAmount*monthlyInterest / 
        		         (1 - (Math.pow(1 / (1 + monthlyInterest),
        		         numOfYears + 12)));
        balance= loanAmount;
        
        // Monthly payment and total payment
        System.out.println();
        System.out.println("Monthly Payment: " 
        		+ (int) (monthlyPayment * 100) / 100.0 );
        System.out.println("Total Payment: "
        	+ (int) (monthlyPayment * 12 * numOfYears * 100) / 
        	100.00 + "\n" );
        
        
System.out.println("Payment#\tInterest\tPrincipal\tBalance");
  		int i;
  		for (i = 1; i <= numOfYears * 12; i++)
  		{
  			interest = (int) (monthlyInterest * balance * 100)
  					/100.0;
  			principal = (int) (monthlyPayment - interest)*100 / 100.00;
  			System.out.println(i + "\t\t" + interest + "\t\t"
  					+ principal + "\t\t" + balance);
  			
  			
  		}
        
        
	}

}
