
public class ExceptionTestClass {

	public static void main(String[] args)  throws IllegalTriangleException{
		// TODO Auto-generated method stub

		
		Triangle triangle=new Triangle (2.0, 3.0, 10.0);
	}

}
