package cpt6;
import java.util.*;
public class chpt6_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{int number;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number: ");
		number=in.nextInt();
		if(isPalindrome(number))
		    System.out.println(number+" is a palindrome");
		else
		     System.out.println(number+" is not a palindrome");}
		}
		public static int reverse(int n)
		{int num=0,digit;
		while(n!=0)
		   {digit=n%10;
		   n/=10;
		   num=num*10+digit;
		   }
		return num;
		}
		public static boolean isPalindrome(int number)
		{
		if(number==reverse(number))
		     return true;
		else
		     return false;
		}
		}
