class Person

{

   String FirstName;

   String LastName;

     Person(String fName, String lName)

     {

              FirstName = fName;

              LastName = lName;

      }

   void Display()

   {

   System.out.println("First Name : " + FirstName);

   System.out.println("Last Name : " + LastName);

   }

}

class InheritanceDemo

{

   public static void main(String args[])

   {

   Person pObj = new Person("John","Dugas");

   Student sObj = new Student("Chris","Smith",1,"1 - B","Amy");

               Teacher tObj = new Teacher("Michael","Novak","English","6000","Primary Teacher");

               System.out.println("Person :");

   pObj.Display();

               System.out.println("");

               System.out.println("Student :");

               sObj.Display();

               System.out.println("");

               System.out.println("Teacher :");

               tObj.Display();

   }

}