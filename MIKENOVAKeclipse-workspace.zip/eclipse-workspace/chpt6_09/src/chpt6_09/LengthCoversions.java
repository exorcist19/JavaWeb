package chpt6_09;

public class LengthCoversions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double feet;
		double meter;
		
		String header1="Feet";
		String header2="Meters";
		
	System.out.printf("5-10%-10s | %15s%12s \n",
			header1,header2,header2,header1);
	System.out.println
	("----------------------------------------------------------");
	
	for(feet=1,meter=20;feet<=10;feet++,
	meter=meter+5)
	System.out.printf("%-10.1f%-10.3f | %15.1f%12.3\n",feet,footToMeter(feet),
							meter,meterToFoot(meter));
	}
	private static double meterToFoot(double meter)
	{
		return meter*3.279;
	}
	private static double footToMeter(double foot)
	{
		return 0.305*foot;
	}

}
