/**
 * 
 */
/**
 * @author Mike Novak
 *
 */
module chpt4unicode {
}