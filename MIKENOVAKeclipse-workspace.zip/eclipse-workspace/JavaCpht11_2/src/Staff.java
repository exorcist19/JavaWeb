public class Staff extends Employee {

//Declaring variables

		private String title;

public Staff(String name, String address, String phoneNo, String email,

	String office, double salary, MyDate dateHired, String title) {

super(name, address, phoneNo, email, office, salary, dateHired);

	this.title = title;

}

public String getTitle() {

	return title;

}

public void setTitle(String title) {

	this.title = title;

}

@Override

public String toString() {

	return "Staff [Name =" + super.getName() + "]";

}

}