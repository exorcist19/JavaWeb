public class Student extends Person {

private String classStatus;

public Student(String name, String address, String phoneNo, String email,String classStatus) {

	super(name, address, phoneNo, email);

		this.classStatus = classStatus;

}

@Override

public String toString() {

	return "Student [Name :"+super.getName()+"]";

}

}