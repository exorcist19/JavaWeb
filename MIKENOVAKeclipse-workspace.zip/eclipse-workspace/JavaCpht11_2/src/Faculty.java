public class Faculty extends Employee {

	private int officeHours;

	private int rank;

public Faculty(String name, String address, String phoneNo, String email,

		String office, double salary, MyDate dateHired, int officeHours,

		int rank) {

super(name, address, phoneNo, email, office, salary, dateHired);

	this.officeHours = officeHours;

			this.rank = rank;

}

public int getOfficeHours() {

		return officeHours;

}

public void setOfficeHours(int officeHours) {

	this.officeHours = officeHours;

}

public int getRank() {

	return rank;

}

public void setRank(int rank) {

	this.rank = rank;

}

@Override

public String toString() {

	return "Faculty [Name =" + super.toString() + "]";


	
	}

}
