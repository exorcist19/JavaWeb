public class Test {

public static void main(String[] args) {

	Student st = new Student("Novak", "103, Wilson Street", "9848425878","Novak123@gmail.com", "Junior");

// Displaying the Student Details

	System.out.println(st.toString());

	MyDate dateHired = new MyDate(2007, 06, 06);

Employee emp = new Employee("summer", "101, Pine Street","9019208993", "summer22@gmail.com", "Microsoft", 50000,dateHired);

// Displaying the Employee Details

	System.out.println(emp.toString());

	MyDate dateHired1 = new MyDate(2002, 05, 06);

Faculty f=new Faculty("Julie","304, Taunton Road","9666242333","jule1@gmail.com", "Joi-co", 65000, dateHired1, 8, 3);

// Displaying the Faculty Details

	System.out.println(f.toString());

	MyDate dateHired2 = new MyDate(2005, 07,21);

	Staff stf=new Staff("Mercer","302, Smuggler's Road", "9884561234","Moijo@outlook.com","Straca Consulting", 75000, dateHired2,"Manager");

// Displaying the Staff Details

System.out.println(stf.toString());

}

}