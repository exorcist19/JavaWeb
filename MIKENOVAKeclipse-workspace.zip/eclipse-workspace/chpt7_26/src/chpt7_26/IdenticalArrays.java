package chpt7_26;
import java.util.Arrays;
import java.util.Scanner;
public class IdenticalArrays {

	
		public static void main(String[] args){
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter List 1 :");
			int first = sc.nextInt();
			int list1[] = new int[first];
			for(int i=0;i<first;i++){
			list1[i] = sc.nextInt();
			}
			System.out.print("Enter List 2 :");
			int second = sc.nextInt();
			int list2[] = new int[second];
			for(int i=0;i<second;i++){
			list2[i] = sc.nextInt();
			}
			if(equals(list1,list2)){
			System.out.println("Two lists are strictly identical");
			}else{
			System.out.println("Two lists are not strictly identical");
			}
			}
			public static boolean equals(int list1[],int list2[]){
			return Arrays.equals(list1, list2);
			}
	}


