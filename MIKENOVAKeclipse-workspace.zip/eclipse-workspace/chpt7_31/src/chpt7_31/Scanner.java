package chpt7_31;

public interface Scanner {

}
