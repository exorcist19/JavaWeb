package chpt7_31;

import java.utils.Scanner;

public class MergeTwoAssortedLists
{
		public static void main(String[] args)
		
			Scanner input = new Scanner(System.in);
			System.out.print("Enter list1: ");
			int size1 = input.nextInt();
			System.out.print("Enter list2: ");
			int size2 =  input.nextInt();
			
			int[] list2 = new int[size2];
			
			for (i = 0; i < list2.length; i++)
				list2[i] = input.nextInt();
			
			int[] mergedList = merge(list1, list2);
			
			System.out.print("\nThe merged list is ");
			for (int i = 0; i < mergedList.length; i++)
				
			{
				System.out.print(mergedList[i] + "` ");	
			}
			
		private static int[] merge(int[] list1, int[] list2)
		{
			int newList[] = new int [list1.length + list2.length];
			int p =0, q = 0;
			
			for (int i = 0; i < newList.length; i++)
			{
				newList[i] = list1[p];
				p++;
				
			}
			else
			{
				newList[i] = list2[q];
				q++;
			}	
		}
		return newList;
		
}