
public class MyDate{
private int month, day, year;
public MyDate(int month, int day, int year){
this.day = day;
this.month =month;
this.year = year;
}
}
