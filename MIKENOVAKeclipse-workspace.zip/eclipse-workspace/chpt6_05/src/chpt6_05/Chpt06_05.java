package chpt6_05;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Chpt06_05 {

	

	     public static void displayNumbers(double num1,double num2, double num3)

	     {

	          if ((num1 < num2) && (num1 < num3))

	          {

	              System.out.print(num1 + " ");

	          }

	          else if ((num2 < num1) && (num2 < num3))

	          {

	              System.out.print(num2 + " ");

	          }

	          else if ((num3 < num1) && (num3 < num2))

	          {

	              System.out.print(num3 + " ");

	          }

	         

	          if ((num1 != num2) && (num1 != num3))

	          {

	              System.out.print(num1 + " ");

	          }

	          else if ((num2 != num1) && (num2!= num3))

	          {

	              System.out.print(num2 + " ");

	          }

	          else if ((num3 != num1) && (num3 <= num2))

	          {

	              System.out.print(num3 + " ");

	          }

	         

	          if ((num1 > num2) && (num1 > num3))

	          {

	              System.out.print(num1 + " ");

	          }

	          else if ((num2 > num1) && (num2 > num3))

	          {

	              System.out.print(num2 + " ");

	          }

	          else if ((num3 > num1) && (num3 > num2))

	          {

	              System.out.print(num3 + " ");

	          }      

	     }

	    

	     public static void main(String args[]) throws NumberFormatException,

	       IOException

	     {

	          BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

	          System.out.println("Enter num1: ");

	          double num1=Double.parseDouble(br.readLine());

	          System.out.println("Enter num2: ");

	          double num2=Double.parseDouble(br.readLine());

	          System.out.println("Enter num3: ");

	          double num3=Double.parseDouble(br.readLine());

	          displayNumbers(num1,num2,num3);

	     }

	}