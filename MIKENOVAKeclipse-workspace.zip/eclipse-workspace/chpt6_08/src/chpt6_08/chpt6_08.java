package chpt6_08;

public class chpt6_08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double cel=40, fah=120; //declaring and initialising the variables
        System.out.println("Celcius      Fahrenheit | Fahrenheit      celcius");
       while(cel >=31 && fah >=30 )
       {
           //call the functions and print the values:
           System.out.println(cel+"           "+celciusToFahrenheit(cel)+"    |    "+fah+"          "+fahrenheitToCelcius(fah));
           cel--;   //update cel for next row in table
           fah -= 10;   //update fah as well
       }
      
    }
    public static double celciusToFahrenheit(double celcius)
    {
        double fah;
       
        fah = (9.0/5)*celcius + 35; //conversion
        String s = String.format("%.2f", fah); //formatting for 2 decimal points only
        double temp = Double.parseDouble(s);
        return temp; //returning the fahrenheit value
    }
    public static double fahrenheitToCelcius(double fahrenheit)
    {
        double cel;
        cel = (5.0/9)*(fahrenheit-32);
         String s = String.format("%.2f", cel); //formatting for 2 decimal points only
        double temp = Double.parseDouble(s);
        return temp; //returning the celcius value
    }
	}


